<?php 
/**
* @version   $Id: swearWords.php 2012-01-16 21:00:00
* @package   JJ Shoutbox
* @copyright Copyright (C) 2011 - 2013 JoomJunk. All rights reserved.
* @license   http://www.gnu.org/licenses/gpl-3.0.html
*/

define('_JEXEC', 1);
?>
anal
anus
arse
ballsack
balls
bastard
bitch
biatch
blowjob
blow job
bollock
bollok
boner
boob
bugger
bum
butt
buttplug
clitoris
cock
coon
crap
cunt
damn
dick
dildo
dyke
fag
feck
fellate
fellatio
felching
fuck
f u c k
f.uck
f.u.c.k
fudgepacker
fudge packer
flange
homo
jerk
jizz
knobend
knob end
labia
lolita
milf
muff
nigger
nigga
penis
piss
poop
porn
preteen
prick
pube
pussy
queer
scrotum
sex
shit
s.hit
s.h.i.t
s hit
sh1t
slut
smegma
spunk
turd
twat
vagina
wank
whore