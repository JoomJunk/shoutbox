DROP TABLE IF EXISTS `#__shoutbox`
